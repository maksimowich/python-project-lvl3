class Not200StatusResponse(Exception):
    pass


class NonExistingDirectory(Exception):
    pass
